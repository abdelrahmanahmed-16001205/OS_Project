package scheduling;

import java.util.ArrayList;

public class SJF extends Scheduler {
    public SJF(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println(" SJF (Shortest Job First - Non-Preemptive) ");
        ArrayList<Process> ready = new ArrayList<>();
        int i = 0;
        while (processes.size() > ganttChart.size()) {
            while (i < processes.size() && processes.get(i).getArrivalTime() <= currentTime) {
                ready.add(processes.get(i++));
            }
            if (ready.isEmpty()) { currentTime++; continue; }
            Process shortest = ready.get(0);
            for (Process p : ready) if (p.getBurstTime() < shortest.getBurstTime()) shortest = p;
            ready.remove(shortest);
            shortest.setFirstRunTime(currentTime);
            ganttChart.add(shortest.getPid());
            currentTime += shortest.getBurstTime();
            ganttTimes.add(currentTime);
            shortest.setCompletionTime(currentTime);
        }
        printGanttChart();
        calculateMetrics();
    }
}