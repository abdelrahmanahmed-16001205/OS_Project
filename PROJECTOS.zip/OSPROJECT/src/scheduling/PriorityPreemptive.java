package scheduling;

import java.util.ArrayList;

public class PriorityPreemptive extends Scheduler {
    public PriorityPreemptive(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Priority Scheduling (Preemptive)");
        int completed = 0;
        while (completed < processes.size()) {
            Process best = null;
            for (Process p : processes) {
                if (p.getArrivalTime() <= currentTime && p.getRemainingTime() > 0) {
                    if (best == null || p.getPriority() < best.getPriority()) {
                        best = p;
                    }
                }
            }
            if (best == null) { currentTime++; continue; }
            if (best.getFirstRunTime() == -1) best.setFirstRunTime(currentTime);
            ganttChart.add(best.getPid());
            best.setRemainingTime(best.getRemainingTime() - 1);
            currentTime++;
            ganttTimes.add(currentTime);
            if (best.getRemainingTime() == 0) {
                best.setCompletionTime(currentTime);
                completed++;
            }
        }
        printGanttChart();
        calculateMetrics();
    }
}