package scheduling;

import java.util.*;

public class MultiLevelQueue extends Scheduler {

    public MultiLevelQueue(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Multi-Level Queue (MLQ) Scheduling");
        System.out.println("Queue 1: FCFS (System processes)");
        System.out.println("Queue 2: SJF  (Interactive processes)");
        System.out.println("Queue 3: Round Robin Q=4 (Batch processes)");


        ArrayList<Process> q1 = new ArrayList<>(); 
        ArrayList<Process> q2 = new ArrayList<>(); 
        ArrayList<Process> q3 = new ArrayList<>(); 

        for (Process p : processes) {
            int prio = p.getPriority();
            if (prio == 1) {
                q1.add(p);
            } else if (prio == 2) {
                q2.add(p);
            } else {
                q3.add(p);
            }
        }

        runFCFS(q1);
        runSJF(q2);
        runRR(q3, 4);

        printGanttChart();
        calculateMetrics();
    }

    private void runFCFS(ArrayList<Process> list) {
        for (Process p : list) {
            while (currentTime < p.getArrivalTime()) currentTime++;
            if (p.getFirstRunTime() == -1) p.setFirstRunTime(currentTime);
            ganttChart.add(p.getPid());
            currentTime += p.getBurstTime();
            ganttTimes.add(currentTime);
            p.setCompletionTime(currentTime);
        }
    }

    private void runSJF(ArrayList<Process> list) {
        int i = 0;
        while (i < list.size()) {
            ArrayList<Process> ready = new ArrayList<>();
            while (i < list.size() && list.get(i).getArrivalTime() <= currentTime) {
                ready.add(list.get(i));
                i++;
            }
            if (ready.isEmpty()) { currentTime++; continue; }

            Process shortest = ready.get(0);
            for (Process p : ready) {
                if (p.getBurstTime() < shortest.getBurstTime()) {
                    shortest = p;
                }
            }
            if (shortest.getFirstRunTime() == -1) shortest.setFirstRunTime(currentTime);
            ganttChart.add(shortest.getPid());
            currentTime += shortest.getBurstTime();
            ganttTimes.add(currentTime);
            shortest.setCompletionTime(currentTime);
        }
    }

    private void runRR(ArrayList<Process> list, int quantum) {
        LinkedList<Process> queue = new LinkedList<>();
        for (Process p : list) queue.add(p);
        int i = 0;

        while (!queue.isEmpty()) {
            while (i < list.size() && list.get(i).getArrivalTime() <= currentTime) {
                if (!queue.contains(list.get(i))) queue.add(list.get(i));
                i++;
            }

            Process p = queue.poll();
            if (p.getFirstRunTime() == -1) p.setFirstRunTime(currentTime);

            int exec = Math.min(quantum, p.getRemainingTime());
            ganttChart.add(p.getPid());
            currentTime += exec;
            ganttTimes.add(currentTime);
            p.setRemainingTime(p.getRemainingTime() - exec);

            while (i < list.size() && list.get(i).getArrivalTime() <= currentTime) {
                if (!queue.contains(list.get(i))) queue.add(list.get(i));
                i++;
            }

            if (p.getRemainingTime() > 0) {
                queue.add(p);
            } else {
                p.setCompletionTime(currentTime);
            }
        }
    }
}