package scheduling;
 
import java.util.*;
 
public class FCFS extends Scheduler {
    public FCFS(ArrayList<Process> processes) {
        super(processes);
    }
 
    @Override
    public void run() {
        System.out.println("FCFS (First Come First Served)");
        for (Process p : processes) {
            while (currentTime < p.getArrivalTime()) {
             currentTime++;
            }
            p.setFirstRunTime(currentTime);
            ganttChart.add(p.getPid());
            currentTime += p.getBurstTime();
            ganttTimes.add(currentTime);
            p.setCompletionTime(currentTime);
        }
        printGanttChart();
        calculateMetrics();
    }
}