package Scheduling;

import java.util.ArrayList;

public class PriorityPreemptive extends Scheduler {
    public PriorityPreemptive(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Priority Scheduling (Preemptive)");

        int done = 0;

        while (done < processes.size()) {
            Process current = null;

            // ! find highest priority process
            for (Process p : processes) {
                if (p.getArrivalTime() <= currentTime && p.getRemainingTime() > 0) {
                    if (current == null) {
                        current = p;
                    } else {
                        if (p.getPriority() > current.getPriority()) {
                            current = p;
                        } else if (p.getPriority() == current.getPriority()) {
                            if (p.getArrivalTime() < current.getArrivalTime()) {
                                current = p;
                            } else if (p.getArrivalTime() == current.getArrivalTime()) {
                                if (p.getPid().compareTo(current.getPid()) < 0) {
                                    current = p;
                                }
                            }
                        }
                    }
                }
            }

            if (current == null) {
                currentTime++;
                continue;
            }

            if (current.getFirstRunTime() == -1) {
                current.setFirstRunTime(currentTime);
            }

            ganttChart.add(current.getPid());
            current.setRemainingTime(current.getRemainingTime() - 1);
            currentTime++;
            ganttTimes.add(currentTime);

            // ! check if process completed
            if (current.getRemainingTime() == 0) {
                current.setCompletionTime(currentTime);
                done++;
            }
        }

        printGanttChart();
        calculateMetrics();
    }
}