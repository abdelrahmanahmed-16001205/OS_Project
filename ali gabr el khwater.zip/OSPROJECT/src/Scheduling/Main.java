package Scheduling;

import java.io.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        String[] files = {
            "Processes.csv",
            "Proccess2.csv",
            "Proccess3.csv",
            "Proccess4.csv",
            "Proccess5.csv"
        };

        if (args.length > 0) {
            files = new String[] { args[0] };
        }

        for (String file : files) {
            System.out.println("\n" + "=".repeat(70));
            System.out.println("  TEST FILE: " + file);
            System.out.println("=".repeat(70) + "\n");

            ArrayList<Process> list = loadCSV(file);
            if (list != null) {
                runSchedulers(list);
            }
        }
    }

    private static ArrayList<Process> loadCSV(String file) {
        ArrayList<Process> list = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            br.readLine();
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");
                list.add(new Process(
                        d[0].trim(),
                        Integer.parseInt(d[1].trim()),
                        Integer.parseInt(d[2].trim()),
                        Integer.parseInt(d[3].trim())));
            }
            br.close();
            return list;

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    private static void runSchedulers(ArrayList<Process> list) {
        new FCFS(list).run();
        new SJF(list).run();
        new PriorityNonPreemptive(list).run();
        new PriorityPreemptive(list).run();
        new RoundRobin(list, 2).run();
        new MultiLevelQueue(list).run();
        new MultiLevelFeedbackQueue(list).run();
    }
}