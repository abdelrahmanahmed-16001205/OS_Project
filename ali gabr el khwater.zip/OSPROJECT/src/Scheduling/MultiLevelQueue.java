package Scheduling;

import java.util.*;

public class MultiLevelQueue extends Scheduler {
    public MultiLevelQueue(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Multi-Level Queue (MLQ)");
        System.out.println("Queue 1: SJF ,Non-Preemptive (Highest)");
        System.out.println("Queue 2: Round Robin (Q=10)");
        System.out.println("Queue 3: FCFS (Lowest)");

        ArrayList<Process> q1 = new ArrayList<>();
        ArrayList<Process> q2 = new ArrayList<>();
        ArrayList<Process> q3 = new ArrayList<>();

        for (Process p : processes) {
            if (p.getPriority() >= 3) {
                q1.add(p);
            } else if (p.getPriority() == 2) {
                q2.add(p);
            } else {
                q3.add(p);
            }
        }

        Queue<Process> rrQueue = new LinkedList<>();

        int completed = 0;
        int total = processes.size();

        while (completed < total) {
            Iterator<Process> q2It = q2.iterator();
            while (q2It.hasNext()) {
                Process p = q2It.next();
                if (p.getArrivalTime() <= currentTime) {
                    rrQueue.add(p);
                    q2It.remove();
                }
            }

            Process selected = null;
            int queueType = 0;

            // ! Check Q1 SJF
            for (Process p : q1) {
                if (p.getArrivalTime() <= currentTime && p.getRemainingTime() > 0) {
                    if (selected == null || p.getBurstTime() < selected.getBurstTime()) {
                        selected = p;
                        queueType = 1;
                    } else if (p.getBurstTime() == selected.getBurstTime()) {
                        // tie breaker
                        if (p.getArrivalTime() < selected.getArrivalTime()) {
                            selected = p;
                            queueType = 1;
                        }
                    }
                }
            }

            // ! Check Q2 RR
            if (selected == null && !rrQueue.isEmpty()) {
                selected = rrQueue.poll();
                queueType = 2;
            }

            // ! Check Q3 FCFS
            if (selected == null) {
                for (Process p : q3) {
                    if (p.getArrivalTime() <= currentTime && p.getRemainingTime() > 0) {
                        if (selected == null) {
                            selected = p;
                            queueType = 3;
                        } else if (p.getArrivalTime() < selected.getArrivalTime()) {
                            selected = p;
                            queueType = 3;
                        } else if (p.getArrivalTime() == selected.getArrivalTime()) {
                            if (p.getPid().compareTo(selected.getPid()) < 0) {
                                selected = p;
                                queueType = 3;
                            }
                        }
                    }
                }
            }

            if (selected == null) {
                if (!ganttChart.isEmpty() && ganttChart.get(ganttChart.size() - 1).equals("Idle")) {
                    ganttTimes.set(ganttTimes.size() - 1, currentTime + 1);
                } else {
                    ganttChart.add("Idle");
                    ganttTimes.add(currentTime + 1);
                }
                currentTime++;
                continue;
            }

            if (selected.getFirstRunTime() == -1) {
                selected.setFirstRunTime(currentTime);
            }

            if (queueType == 1) {
                // ! Q1 SJF
                ganttChart.add(selected.getPid());
                int remaining = selected.getRemainingTime();
                currentTime += remaining;
                ganttTimes.add(currentTime);
                selected.setRemainingTime(0);
                selected.setCompletionTime(currentTime);
                completed++;

            } else if (queueType == 2) {
                // ! Q2 Round Robin
                int quantum = 10;
                int exec = selected.getRemainingTime();
                if (exec > quantum) {
                    exec = quantum;
                }
                ganttChart.add(selected.getPid());
                currentTime += exec;
                ganttTimes.add(currentTime);
                int newRemaining = selected.getRemainingTime() - exec;
                selected.setRemainingTime(newRemaining);

                if (newRemaining == 0) {
                    selected.setCompletionTime(currentTime);
                    completed++;
                } else {
                    rrQueue.add(selected);
                }

            } else if (queueType == 3) {
                // ! Q3 FCFS
                ganttChart.add(selected.getPid());
                int burstLeft = selected.getRemainingTime();
                currentTime += burstLeft;
                ganttTimes.add(currentTime);
                selected.setRemainingTime(0);
                selected.setCompletionTime(currentTime);
                completed++;
            }
        }

        printGanttChart();
        calculateMetrics();
    }
}