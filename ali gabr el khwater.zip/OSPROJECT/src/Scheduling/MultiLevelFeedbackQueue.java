package Scheduling;

import java.util.*;

public class MultiLevelFeedbackQueue extends Scheduler {

    public MultiLevelFeedbackQueue(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Multi-Level Feedback Queue (MLFQ)");
        System.out.println("Queue 1: Quantum = 2");
        System.out.println("Queue 2: Quantum = 4");
        System.out.println("Queue 3: FCFS");

        ArrayList<Process> sorted = new ArrayList<>(processes);
        for (int i = 0; i < sorted.size() - 1; i++) {
            for (int j = 0; j < sorted.size() - i - 1; j++) {
                if (sorted.get(j).getArrivalTime() > sorted.get(j + 1).getArrivalTime()) {
                    Process temp = sorted.get(j);
                    sorted.set(j, sorted.get(j + 1));
                    sorted.set(j + 1, temp);
                }
            }
        }

        LinkedList<Process>[] queues = new LinkedList[3];
        for (int i = 0; i < 3; i++) {
            queues[i] = new LinkedList<>();
        }

        int index = 0;
        int completed = 0;
        int total = processes.size();

        while (completed < total) {
            while (index < sorted.size() && sorted.get(index).getArrivalTime() <= currentTime) {
                queues[0].add(sorted.get(index));
                index++;
            }

            Process selected = null;
            int qType = -1;

            // !find first non empty q
            for (int i = 0; i < 3; i++) {
                if (!queues[i].isEmpty()) {
                    selected = queues[i].poll();
                    qType = i;
                    break;
                }
            }

            // ! idle time
            if (selected == null) {
                if (!ganttChart.isEmpty() && ganttChart.get(ganttChart.size() - 1).equals("Idle")) {
                    ganttTimes.set(ganttTimes.size() - 1, currentTime + 1);
                } else {
                    ganttChart.add("Idle");
                    ganttTimes.add(currentTime + 1);
                }
                currentTime++;
                continue;
            }

            if (selected.getFirstRunTime() == -1) {
                selected.setFirstRunTime(currentTime);
            }

            // ! time slice
            int timeSlice = 0;
            if (qType == 0) {
                timeSlice = 2;
            } else if (qType == 1) {
                timeSlice = 4;
            } else {
                timeSlice = selected.getRemainingTime();
            }

            int execTime = timeSlice;
            if (selected.getRemainingTime() < timeSlice) {
                execTime = selected.getRemainingTime();
            }

            ganttChart.add(selected.getPid());
            currentTime += execTime;
            ganttTimes.add(currentTime);

            int remaining = selected.getRemainingTime() - execTime;
            selected.setRemainingTime(remaining);

            while (index < sorted.size() && sorted.get(index).getArrivalTime() <= currentTime) {
                queues[0].add(sorted.get(index));
                index++;
            }

            if (remaining > 0) {
                // ! to next queue
                int nextQ = qType + 1;
                if (nextQ > 2) {
                    nextQ = 2;
                }
                queues[nextQ].add(selected);
            } else {
                selected.setCompletionTime(currentTime);
                completed++;
            }
        }

        printGanttChart();
        calculateMetrics();
    }
}