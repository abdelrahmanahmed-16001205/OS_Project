package Scheduling;

import java.util.*;

public class RoundRobin extends Scheduler {
    private int quantum;

    public RoundRobin(ArrayList<Process> processes, int quantum) {
        super(processes);
        this.quantum = quantum;
    }

    @Override
    public void run() {
        System.out.println("Round Robin (Quantum = " + quantum + ")");

        Queue<Process> ready = new LinkedList<>();
        int done = 0;
        int index = 0;
        Process current = null;
        int timeUsed = 0;

        while (done < processes.size()) {
            while (index < processes.size() &&
                    processes.get(index).getArrivalTime() <= currentTime) {
                ready.add(processes.get(index));
                index++;
            }

            if (current == null) {
                current = ready.poll();
                timeUsed = 0;
            }

            if (current == null) {
                currentTime++;
                continue;
            }

            if (current.getFirstRunTime() == -1) {
                current.setFirstRunTime(currentTime);
            }

            ganttChart.add(current.getPid());
            current.setRemainingTime(current.getRemainingTime() - 1);
            currentTime++;
            ganttTimes.add(currentTime);
            timeUsed++;

            // ! check lw done aw quantum expired
            if (current.getRemainingTime() == 0) {
                current.setCompletionTime(currentTime);
                done++;
                current = null;
            } else if (timeUsed == quantum) {
                ready.add(current);
                current = null;
            }
        }

        printGanttChart();
        calculateMetrics();
    }
}