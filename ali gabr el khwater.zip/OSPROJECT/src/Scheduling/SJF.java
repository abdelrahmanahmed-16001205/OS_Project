package Scheduling;

import java.util.ArrayList;

public class SJF extends Scheduler {
    public SJF(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("SJF (Shortest Job First, Non-Preemptive)");

        for (int i = 0; i < processes.size() - 1; i++) {
            for (int j = 0; j < processes.size() - i - 1; j++) {
                if (processes.get(j).getArrivalTime() > processes.get(j + 1).getArrivalTime()) {
                    Process temp = processes.get(j);
                    processes.set(j, processes.get(j + 1));
                    processes.set(j + 1, temp);
                }
            }
        }

        ArrayList<Process> ready = new ArrayList<>();
        int index = 0;

        while (ganttChart.size() < processes.size()) {

            while (index < processes.size() && processes.get(index).getArrivalTime() <= currentTime) {
                ready.add(processes.get(index));
                index++;
            }

            if (ready.isEmpty()) {
                if (index < processes.size()) {
                    currentTime = processes.get(index).getArrivalTime();
                }
                continue;
            }

            // ! shortest Job
            Process current = ready.get(0);
            for (int i = 1; i < ready.size(); i++) {
                Process p = ready.get(i);
                if (p.getBurstTime() < current.getBurstTime()) {
                    current = p;
                } else if (p.getBurstTime() == current.getBurstTime() &&
                        p.getPid().compareTo(current.getPid()) < 0) {
                    current = p;
                }
            }

            ready.remove(current);
            current.setFirstRunTime(currentTime);
            ganttChart.add(current.getPid());
            currentTime += current.getBurstTime();
            ganttTimes.add(currentTime);
            current.setCompletionTime(currentTime);
        }

        printGanttChart();
        calculateMetrics();
    }
}