package Scheduling;

import java.util.ArrayList;

public abstract class Scheduler {
    protected ArrayList<Process> processes;
    protected ArrayList<String> ganttChart;
    protected ArrayList<Integer> ganttTimes;
    protected int currentTime;

    public Scheduler(ArrayList<Process> processes) {
        this.processes = new ArrayList<>();
        for (Process p : processes) {
            this.processes.add(new Process(p.getPid(), p.getArrivalTime(), p.getBurstTime(), p.getPriority()));
        }
        this.ganttChart = new ArrayList<>();
        this.ganttTimes = new ArrayList<>();
        this.currentTime = 0;
    }

    public abstract void run();

    protected void calculateMetrics() {
        int totalWT = 0;
        int totalTAT = 0;
        int totalRT = 0;
        int totalBurst = 0;
        int done = 0;
        int maxCT = 0;

        System.out.println("Process | CT | TAT | WT | RT");
        System.out.println("--------|----|----|----|----|");

        for (Process p : processes) {
            totalBurst += p.getBurstTime();

            // !completed procces only
            if (p.getCompletionTime() > 0) {
                int tat = p.getCompletionTime() - p.getArrivalTime();
                int wt = tat - p.getBurstTime();
                int rt = (p.getFirstRunTime() != -1) ? (p.getFirstRunTime() - p.getArrivalTime()) : 0;

                p.setTurnaroundTime(tat);
                p.setWaitingTime(wt);
                p.setResponseTime(rt);

                System.out.println(
                        p.getPid() + "       | " + p.getCompletionTime() + "  | " + tat + "  | " + wt + "  | " + rt);

                // !averages
                totalWT += wt;
                totalTAT += tat;
                totalRT += rt;
                maxCT = Math.max(maxCT, p.getCompletionTime());
                done++;
            }
        }

        System.out.println();

        if (done > 0) {
            double avgWT = (double) totalWT / done;
            double avgTAT = (double) totalTAT / done;
            double avgRT = (double) totalRT / done;
            double throughput = (double) done / maxCT;
            double cpuUtil = (double) totalBurst * 100.0 / maxCT;

            System.out.println("Average Waiting Time     : " + avgWT);
            System.out.println("Average Turnaround Time  : " + avgTAT);
            System.out.println("Average Response Time    : " + avgRT);
            System.out.println("Throughput               : " + throughput + " processes/unit time");
            System.out.println("CPU Utilization          : " + cpuUtil + "%");
        } else {
            System.out.println("No processes completed.");
        }

        System.out.println();
    }

    public void printGanttChart() {
        System.out.println("Gantt Chart:");

        System.out.print("|");
        for (String pid : ganttChart) {
            System.out.print(" " + pid + " |");
        }
        System.out.println();

        System.out.print("0");

        for (int i = 0; i < ganttTimes.size(); i++) {
            int time = ganttTimes.get(i);
            String pid = ganttChart.get(i);
            String timeStr = String.valueOf(time);

            int cellWidth = 3 + pid.length();
            int spaces = cellWidth - timeStr.length();

            for (int j = 0; j < spaces; j++) {
                System.out.print(" ");
            }
            System.out.print(time);
        }
        System.out.println("\n");
    }

    protected Process findProcessByPid(String pid) {
        int i = 0;
        while (i < processes.size()) {
            if (processes.get(i).getPid().equals(pid)) {
                return processes.get(i);
            }
            i = i + 1;
        }
        return null;
    }
}