package Scheduling;

public class Process {
    private final String pid;
    private final int arrivalTime;
    private final int burstTime;
    private int priority; // ! msh final 3shan el bonus (multi level)

    private int remainingTime;
    private int completionTime;
    private int turnaroundTime;
    private int waitingTime;
    private int responseTime;
    private int firstRunTime;

    public Process(String pid, int arrivalTime, int burstTime, int priority) {
        if (pid == null || pid.equals("")) {
            throw new IllegalArgumentException("PID cannot be null or empty");
        }
        if (arrivalTime < 0 || burstTime <= 0 || priority < 0) {
            throw new IllegalArgumentException("Invalid process parameters");
        }

        this.pid = pid;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.remainingTime = burstTime;
        this.completionTime = 0;
        this.turnaroundTime = 0;
        this.waitingTime = 0;
        this.responseTime = -1;
        this.firstRunTime = -1;
    }

    public String getPid() {
        return pid;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public int getPriority() {
        return priority;
    }

    public int getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(int remainingTime) {
        this.remainingTime = remainingTime;
    }

    public int getCompletionTime() {
        return completionTime;
    }

    public void setCompletionTime(int completionTime) {
        this.completionTime = completionTime;
    }

    public int getTurnaroundTime() {
        return turnaroundTime;
    }

    public void setTurnaroundTime(int turnaroundTime) {
        this.turnaroundTime = turnaroundTime;
    }

    public int getWaitingTime() {
        return waitingTime;
    }

    public void setWaitingTime(int waitingTime) {
        this.waitingTime = waitingTime;
    }

    public int getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(int responseTime) {
        this.responseTime = responseTime;
    }

    public int getFirstRunTime() {
        return firstRunTime;
    }

    public void setFirstRunTime(int firstRunTime) {
        if (this.firstRunTime == -1) {
            this.firstRunTime = firstRunTime;
        }
    }

    // ! 3shan lw hnshaghal kaza algorithm on the same input
    public void reset() {
        this.remainingTime = this.burstTime;
        this.completionTime = 0;
        this.turnaroundTime = 0;
        this.waitingTime = 0;
        this.responseTime = -1;
        this.firstRunTime = -1;
    }
}