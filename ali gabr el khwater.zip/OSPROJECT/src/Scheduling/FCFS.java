package Scheduling;

import java.util.ArrayList;

public class FCFS extends Scheduler {
    public FCFS(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("FCFS (First Come First Served)");

        for (int i = 0; i < processes.size() - 1; i++) {
            for (int j = 0; j < processes.size() - i - 1; j++) {
                Process current = processes.get(j);
                Process next = processes.get(j + 1);

                if (current.getArrivalTime() > next.getArrivalTime()) {
                    Process temp = current;
                    processes.set(j, next);
                    processes.set(j + 1, temp);
                } else if (current.getArrivalTime() == next.getArrivalTime() &&
                        current.getPid().compareTo(next.getPid()) > 0) {
                    Process temp = current;
                    processes.set(j, next);
                    processes.set(j + 1, temp);
                }
            }
        }

        // ! execute in order
        for (Process p : processes) {
            if (currentTime < p.getArrivalTime()) {
                currentTime = p.getArrivalTime();
            }

            p.setFirstRunTime(currentTime);
            ganttChart.add(p.getPid());
            currentTime += p.getBurstTime();
            ganttTimes.add(currentTime);
            p.setCompletionTime(currentTime);
        }

        printGanttChart();
        calculateMetrics();
    }
}