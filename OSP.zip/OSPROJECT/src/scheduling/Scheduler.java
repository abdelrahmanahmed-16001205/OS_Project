package scheduling;
 
import java.util.ArrayList;
 
public abstract class Scheduler {
    protected ArrayList<Process> processes;
    protected ArrayList<String> ganttChart;
    protected ArrayList<Integer> ganttTimes;
    protected int currentTime;
 
    public Scheduler(ArrayList<Process> processes) {
        this.processes = new ArrayList<>();
        for (Process p : processes) {
            this.processes.add(new Process(p.getPid(), p.getArrivalTime(), p.getBurstTime(), p.getPriority()));
        }
        this.ganttChart = new ArrayList<>();
        this.ganttTimes = new ArrayList<>();
        this.currentTime = 0;
    }
 
    public abstract void run();
 
    protected void calculateMetrics() {
        int totalWT = 0;
        int totalTAT = 0;
        int totalRT = 0;
        int done = 0;
        int maxCT = 0;
 
        System.out.println("Process | CT | TAT | WT | RT");
 
        int i = 0;
        while (i < processes.size()) {
            Process p = processes.get(i);
            if (p.getCompletionTime() > 0) {
                int tat = p.getCompletionTime() - p.getArrivalTime();
                int wt = tat - p.getBurstTime();
                int rt = 0;
                if (p.getFirstRunTime() != -1) {
                    rt = p.getFirstRunTime() - p.getArrivalTime();
                }
                p.setTurnaroundTime(tat);
                p.setWaitingTime(wt);
                p.setResponseTime(rt);
 
                System.out.println(p.getPid() + " | " + p.getCompletionTime() +
                                 " | " + tat + " | " + wt + " | " + rt);
 
                totalWT = totalWT + wt;
                totalTAT = totalTAT + tat;
                totalRT = totalRT + rt;
                if (p.getCompletionTime() > maxCT) {
                    maxCT = p.getCompletionTime();
                }
                done = done + 1;
            }
            i = i + 1;
        }
 
        System.out.println("Average Waiting Time : " + (totalWT * 1.0 / done));
        System.out.println("Average Turnaround Time : " + (totalTAT * 1.0 / done));
        System.out.println("Average Response Time : " + (totalRT * 1.0 / done));
        System.out.println("Throughput : " + (done * 1.0 / maxCT) + " processes/unit time");
        System.out.println("CPU Utilization : 100.00%");
        System.out.println();
    }
 
    public void printGanttChart() {
        System.out.println("Gantt Chart:");
 
        System.out.print("|");
        for (String pid : ganttChart) {
            System.out.print(" " + pid + " |");
        }
        System.out.println();
 
        System.out.print("0");
        
        for (int i = 0; i < ganttTimes.size(); i++) {
            int time = ganttTimes.get(i);
            String pid = ganttChart.get(i);
            String timeStr = String.valueOf(time);
            
            int cellWidth = 3 + pid.length();
            int spaces = cellWidth - timeStr.length();
            
            for (int j = 0; j < spaces; j++) {
                System.out.print(" ");
            }
            System.out.print(time);
        }
        System.out.println("\n");
    }
 
    protected Process findProcessByPid(String pid) {
        int i = 0;
        while (i < processes.size()) {
            if (processes.get(i).getPid().equals(pid)) {
                return processes.get(i);
            }
            i = i + 1;
        }
        return null;
    }
}