package scheduling;

import java.util.*;

public class RoundRobin extends Scheduler {
    private int quantum;

    public RoundRobin(ArrayList<Process> processes, int quantum) {
        super(processes);
        this.quantum = quantum;
    }

    @Override
    public void run() {
        System.out.println("Round Robin (Quantum = " + quantum + ")");
        LinkedList<Process> queue = new LinkedList<>();
        int i = 0;
        int completed = 0;
        
        while (completed < processes.size()) {
            while (i < processes.size() && processes.get(i).getArrivalTime() <= currentTime) {
                queue.add(processes.get(i));
                i++;
            }
            
            if (queue.isEmpty()) { 
                currentTime++; 
                continue; 
            }
            
            Process p = queue.poll();
            if (p.getFirstRunTime() == -1) {
                p.setFirstRunTime(currentTime);
            }
            
            int exec = Math.min(quantum, p.getRemainingTime());
            ganttChart.add(p.getPid());
            currentTime += exec;
            ganttTimes.add(currentTime);
            p.setRemainingTime(p.getRemainingTime() - exec);
            
            while (i < processes.size() && processes.get(i).getArrivalTime() <= currentTime) {
                queue.add(processes.get(i));
                i++;
            }
            
            if (p.getRemainingTime() > 0) {
                queue.add(p);
            } else {
                p.setCompletionTime(currentTime);
                completed++;
            }
        }
        
        printGanttChart();
        calculateMetrics();
    }
}