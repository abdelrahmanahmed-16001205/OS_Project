package scheduling;

import java.io.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        String file = "processes.csv";
        if (args.length > 0) file = args[0];
        ArrayList<Process> list = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            br.readLine();                          
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");
                list.add(new Process(d[0],
                        Integer.parseInt(d[1]),
                        Integer.parseInt(d[2]),
                        Integer.parseInt(d[3])));
            }
            br.close();
        } catch (Exception e) {
            System.out.println("File error: " + e.getMessage());
            return;
        }

        new FCFS(list).run();
        new SJF(list).run();
        new PriorityNonPreemptive(list).run();
        new PriorityPreemptive(list).run();
        new RoundRobin(list, 2).run();
        new MultiLevelQueue(list).run();
        new MultiLevelFeedbackQueue(list).run();
    }
}