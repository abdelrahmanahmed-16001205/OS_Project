package scheduling;

import java.util.ArrayList;

public class PriorityNonPreemptive extends Scheduler {
    public PriorityNonPreemptive(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Priority Scheduling (Non-Preemptive)");
        ArrayList<Process> ready = new ArrayList<>();
        int i = 0;
        while (ganttChart.size() < processes.size()) {
            while (i < processes.size() && processes.get(i).getArrivalTime() <= currentTime) {
                ready.add(processes.get(i++));
            }
            if (ready.isEmpty()) { currentTime++; continue; }
            Process highest = ready.get(0);
            for (Process p : ready) if (p.getPriority() < highest.getPriority()) highest = p;
            ready.remove(highest);
            highest.setFirstRunTime(currentTime);
            ganttChart.add(highest.getPid());
            currentTime += highest.getBurstTime();
            ganttTimes.add(currentTime);
            highest.setCompletionTime(currentTime);
        }
        printGanttChart();
        calculateMetrics();
    }
}