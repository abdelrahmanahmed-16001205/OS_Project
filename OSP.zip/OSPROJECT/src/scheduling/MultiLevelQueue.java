package scheduling;

import java.util.*;

public class MultiLevelQueue extends Scheduler {

    public MultiLevelQueue(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Multi-Level Queue (MLQ) Scheduling");
        System.out.println("Queue 1: FCFS (System processes - Priority 1)");
        System.out.println("Queue 2: SJF  (Interactive processes - Priority 2)");
        System.out.println("Queue 3: Round Robin Q=4 (Batch processes - Priority 3+)");

        ArrayList<Process> q1 = new ArrayList<>(); 
        ArrayList<Process> q2 = new ArrayList<>(); 
        ArrayList<Process> q3 = new ArrayList<>(); 

        for (Process p : processes) {
            int prio = p.getPriority();
            if (prio == 1) {
                q1.add(p);
            } else if (prio == 2) {
                q2.add(p);
            } else {
                q3.add(p);
            }
        }

        runFCFS(q1);
        runSJF(q2);
        runRR(q3, 4);

        printGanttChart();
        calculateMetrics();
    }

    private void runFCFS(ArrayList<Process> list) {
        for (Process p : list) {
            while (currentTime < p.getArrivalTime()) {
                currentTime++;
            }
            if (p.getFirstRunTime() == -1) {
                p.setFirstRunTime(currentTime);
            }
            ganttChart.add(p.getPid());
            currentTime += p.getBurstTime();
            ganttTimes.add(currentTime);
            p.setCompletionTime(currentTime);
        }
    }

    private void runSJF(ArrayList<Process> list) {
        ArrayList<Process> remaining = new ArrayList<>(list);
        
        while (!remaining.isEmpty()) {
            ArrayList<Process> ready = new ArrayList<>();
            for (Process p : remaining) {
                if (p.getArrivalTime() <= currentTime) {
                    ready.add(p);
                }
            }
            
            if (ready.isEmpty()) { 
                currentTime++; 
                continue; 
            }

            Process shortest = ready.get(0);
            for (Process p : ready) {
                if (p.getBurstTime() < shortest.getBurstTime()) {
                    shortest = p;
                }
            }
            
            if (shortest.getFirstRunTime() == -1) {
                shortest.setFirstRunTime(currentTime);
            }
            ganttChart.add(shortest.getPid());
            currentTime += shortest.getBurstTime();
            ganttTimes.add(currentTime);
            shortest.setCompletionTime(currentTime);
            remaining.remove(shortest);
        }
    }

    private void runRR(ArrayList<Process> list, int quantum) {
        if (list.isEmpty()) return;
        
        LinkedList<Process> queue = new LinkedList<>();
        ArrayList<Process> notArrived = new ArrayList<>(list);
        int completed = 0;

        while (completed < list.size()) {
            // Add newly arrived processes
            Iterator<Process> it = notArrived.iterator();
            while (it.hasNext()) {
                Process p = it.next();
                if (p.getArrivalTime() <= currentTime) {
                    queue.add(p);
                    it.remove();
                }
            }

            if (queue.isEmpty()) {
                currentTime++;
                continue;
            }

            Process p = queue.poll();
            if (p.getFirstRunTime() == -1) {
                p.setFirstRunTime(currentTime);
            }

            int exec = Math.min(quantum, p.getRemainingTime());
            ganttChart.add(p.getPid());
            currentTime += exec;
            ganttTimes.add(currentTime);
            p.setRemainingTime(p.getRemainingTime() - exec);

           

            if (p.getRemainingTime() > 0) {
                queue.add(p);
            } else {
                p.setCompletionTime(currentTime);
                completed++;
            }
        }
    }
}