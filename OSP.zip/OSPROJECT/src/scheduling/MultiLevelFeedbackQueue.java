package scheduling;

import java.util.*;

public class MultiLevelFeedbackQueue extends Scheduler {

    public MultiLevelFeedbackQueue(ArrayList<Process> processes) {
        super(processes);
    }

    @Override
    public void run() {
        System.out.println("Multi-Level Feedback Queue (MLFQ) Scheduling");
        System.out.println("Queue 1: Quantum = 2");
        System.out.println("Queue 2: Quantum = 4");
        System.out.println("Queue 3: FCFS (last queue)");

        LinkedList<Process>[] queues = new LinkedList[3];
        for (int i = 0; i < 3; i++) {
            queues[i] = new LinkedList<>();
        }

        int index = 0;

        while (true) {
            while (index < processes.size() && processes.get(index).getArrivalTime() <= currentTime) {
                queues[0].add(processes.get(index));
                index++;
            }

            Process current = null;
            int qIndex = -1;

            for (int i = 0; i < 3; i++) {
                if (!queues[i].isEmpty()) {
                    current = queues[i].peek();
                    qIndex = i;
                    break;
                }
            }

            if (current == null) {
                if (index >= processes.size()) break;
                currentTime++;
                continue;
            }

            queues[qIndex].poll(); 

            if (current.getFirstRunTime() == -1) {
                current.setFirstRunTime(currentTime);
            }

            int quantum = (qIndex == 0) ? 2 : (qIndex == 1) ? 4 : 999;
            int exec = Math.min(quantum, current.getRemainingTime());

            ganttChart.add(current.getPid());
            currentTime += exec;
            ganttTimes.add(currentTime);
            current.setRemainingTime(current.getRemainingTime() - exec);

            while (index < processes.size() && processes.get(index).getArrivalTime() <= currentTime) {
                queues[0].add(processes.get(index));
                index++;
            }

            if (current.getRemainingTime() > 0) {
                int nextQueue = qIndex + 1;
                if (nextQueue < 3) {
                    queues[nextQueue].add(current);
                } else {
                    queues[2].add(current); 
                }
            } else {
                current.setCompletionTime(currentTime);
            }
        }

        printGanttChart();
        calculateMetrics();
    }
}